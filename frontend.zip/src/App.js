import React, { Component } from 'react'
import { w3cwebsocket as W3Cwebsocket } from 'websocket';
import 'antd/dist/antd.css';
import Particles from 'react-tsparticles';
import './App.css'
import Quiz from './components/Quiz';
import Login from './components/Login'
const BSON = require('bson');
const particleParams = {
  fpsLimit: 60,
  particles: {
    number: {
      value: 200,
      density: {
        enable: true,
        value_area: 1600
      }
    },
    color: {
      value: "#0000ff",
      animation: {
        enable: true,
        speed: 5,
        sync: false
      }
    },
    shape: {
      type: "circle",
      stroke: {
        width: 0
      },
      polygon: {
        nb_sides: 5
      },
      image: {
        src: "https://cdn.matteobruni.it/images/particles/github.svg",
        width: 100,
        height: 100
      }
    },
    opacity: {
      value: 0.5,
      random: false,
      anim: {
        enable: false,
        speed: 3,
        opacity_min: 0.1,
        sync: false
      }
    },
    size: {
      value: 3,
      random: true,
      anim: {
        enable: false,
        speed: 20,
        size_min: 0.1,
        sync: false
      }
    },
    line_linked: {
      enable: true,
      distance: 120,
      color: "#ffffff",
      opacity: 0.4,
      width: 1
    },
    move: {
      enable: true,
      speed: 6,
      direction: "none",
      random: false,
      straight: false,
      out_mode: "out",
      attract: {
        enable: true,
        rotateX: 600,
        rotateY: 1200
      }
    },
    life: {
      duration: {
        sync: false,
        value: 3
      },
      count: 0,
      delay: {
        random: {
          enable: true,
          minimumValue: 0.5
        },
        value: 1
      }
    }
  },
  interactivity: {
    detect_on: "canvas",
    events: {
      onhover: {
        enable: true,
        mode: "repulse"
      },
      onclick: {
        enable: true,
        mode: "push"
      },
      resize: true
    },
    modes: {
      grab: {
        distance: 400,
        line_linked: {
          opacity: 1
        }
      },
      bubble: {
        distance: 400,
        size: 40,
        duration: 2,
        opacity: 0.8
      },
      repulse: {
        distance: 200
      },
      push: {
        particles_nb: 4
      },
      remove: {
        particles_nb: 2
      }
    }
  },
  retina_detect: true,
  background: {
    color: "#000000",
    image: "",
    position: "50% 50%",
    repeat: "no-repeat",
    size: "cover"
  }
}

const client = new W3Cwebsocket('ws://127.0.1:8000');

class App extends Component {
  constructor(props) {
    super(props);
    this.handlerIsJoinedIn = this.handlerIsJoinedIn.bind(this);
    this.state = {
      userName: '',
      isJoinedIn: false,
      messages: [],
      questions: []
    }
  }
  
  handlerIsJoinedIn(e) {
    this.setState({
      userName: e.userName,
      isJoinedIn: e.isJoinedIn,
    });
    this.onButtonClicked("i'm here send me my first questoin");
  }
  onButtonClicked = (value) => {
    client.send(JSON.stringify({
      type: "message",
      msg: value,
      user: this.state.userName,
    }));
  }
  componentDidMount() {
    client.onopen = () => {
      console.log('Websocket Client connected');
    };
    
    client.onmessage = (message) => {
      const dataFromServer = JSON.parse(message.data);
      console.log('got replay',message.data);
      console.log('got replay',dataFromServer.answerOptions[0].answerText);
      if(dataFromServer.type === "message") {
        this.setState((state) => ({ 
          messages: [... this.state.messages,
          {
              msg: dataFromServer.msg,
            user: dataFromServer.user
          }]
        }))
      } else if(dataFromServer.type === "question") {
        console.log(dataFromServer.answerOptions)
        this.setState({
          questions: [... this.state.questions,dataFromServer]
        })
      }
    };
  }
  render() {
    const qst = {
        questionText: 'What is the capital of France?',
        answerOptions: [
          { answerText: 'New York', isCorrect: false },
          { answerText: 'London', isCorrect: false },
          { answerText: 'Paris', isCorrect: true },
          { answerText: 'Dublin', isCorrect: false },
        ],
    };
    return (
      <div>
        <Particles 
        params = {particleParams} 
        style={{
          width: '100%',
          backgroundColor: "#453764"
        }}
        className ="particles"/>
        <div>
          {
            this.state.isJoinedIn ?
            <div >
            {
              this.state.questions.length == 0 ? <h1> waiting</h1> :
              <Quiz question={this.state.questions[0]}/>
            }
              <button onClick={() => this.onButtonClicked("hello!")}>Send msg</button>
              {this.state.questions.map(qst => <p key={qst.toString()} >{qst.questionText}:  </p>)}
            
            </div>
            :
              <Login handler={this.handlerIsJoinedIn}/>
          }
        </div>
      </div>
    )
  }
}

export default App;