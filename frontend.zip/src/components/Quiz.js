import React, { Component, useState } from 'react';
export default class extends React.Component {
	render(){
		return (
			<div className='app'>
						<div className='question-section'>
							<div className='question-count'>
								<span>Question </span>
							</div>
							<div className='question-text'>{this.props.question.questionText}</div>
						</div>
						<div className='answer-section'>
							{this.props.question.answerOptions.map((answerOption) => (
								<button onClick={() => handleAnswerOptionClick(answerOption.isCorrect)}>{answerOption.answerText}</button>
							))}
						</div> 
			</div>
		);
	}
}
